﻿function DoTheShitjavaScript() {
    document.getElementById("txtTestFeltjavaScript").value = "Du har trykket " + CounterjavaScript.toString() + " gange på knappen !!!";
    CounterjavaScript++;
}

function DoTheShitjQuery() {
    $("#txtTestFeltjQuery").val("Du har trykket " + CounterjQuery.toString() + " gange på knappen !!!");
    CounterjQuery++;
}